package Tulls;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.*;
public class Prova 
{
	public static void main(String[] args) 
	{
		//instancia um TullFrame
		TullFrame tframe = new TullFrame();
		
		//permite fechar o frame
		tframe.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		//torna o frame vis�vel
		tframe.setVisible(true);
	}
}
//classe TullFrame
class TullFrame extends JFrame
{
	//variavel tipo objeto encapsulado
	private TullPanel tpanel;
	
	//contrutor da classe
	public TullFrame()
	{
		//intitula o Frame
		this.setTitle("UBTapp");
		
		//Instancia classe Tollkit
		Toolkit toolkit = Toolkit.getDefaultToolkit();
		
		//cria uma dimens�o
		Dimension dtela = toolkit.getScreenSize();
		
		//dimensiona a tela com valores
		this.setSize(dtela.height/2, dtela.width/3);
		
		//posiciona a tela
		this.setLocation((int)dtela.height/4, (int)dtela.width/7);
		
		//cria uma imagem
		URL image = this.getClass().getResource("photo.png");
		ImageIcon icon = new ImageIcon(image);
		
		//insere a imagem no titulo do frame.
		this.setIconImage(icon.getImage());
		
		//instancia um TullPanel
		tpanel = new TullPanel();
		
		//define as posi��es dos componentes
		tpanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 80));
		
		//insere o tpanel no TullFrame
		this.add(tpanel);
	}
}
//classe TullPanel
class TullPanel extends JPanel implements ActionListener
{
	//variavel tipo array de string encapsulada
	private String forma[] = {"Chon-Ji", "Dan-Gun", "Do-San", "Won-Hyo", "Yul-Gok", "Joong-Gun", "Toi-Gye", "Hwa-Rang", "Choong-Moo"};
	//variaveis tipo objetos encaplsulado
	private JLabel jl_nome;
	private JComboBox combo;
	private JTextField jt_nome;
	private JButton start, restart;
	private Execucao ex;
	//construtor da classe TullPanel
	public TullPanel()
	{
		//instancia a classe JLabel para inserir um texto
		jl_nome = new JLabel("Participante:");
		
		//seleciona uma cor para o jl_nome
		jl_nome.setForeground(Color.BLACK);
		
		//define uma fonte para o jl_forma
		jl_nome.setFont(new Font("Arial", Font.PLAIN, 20));
		
		//add jl_forma no TullPanel
		this.add(jl_nome);
		
		//Instancia um JTextField
		jt_nome = new JTextField(19);
		
		//add jt_nome no TullPanel
		this.add(jt_nome);
		
		//instancia a classe JLabel para inserir um texto
		JLabel jl_forma = new JLabel("Selecione a forma:");
		
		//seleciona uma cor para o jl_forma
		jl_forma.setForeground(Color.BLACK);
			
		//define uma fonte para o jl_forma
		jl_forma.setFont(new Font("Arial", Font.PLAIN, 22));
				
		//add o jl_forma no TullPanel
		this.add(jl_forma);
		
		//Instancia um combobox
		combo = new JComboBox(forma);
		
		//seleciona a fonte do combo
		combo.setFont(new Font("Arial", Font.PLAIN, 20));
		
		//bloqueia edi��o manual do combo
		combo.setEditable(false);
		
		//add o combo no TullPanel
		this.add(combo);
		
		//instancia os JButtons
		start = new JButton("Come�ar");
		restart = new JButton("Reiniciar");
		
		//define uma fonte aos bot�es
		start.setFont(new Font("Arial", Font.PLAIN, 20));
		restart.setFont(new Font("Arial", Font.PLAIN, 20));
		
		//add os bot�es no TullPanel
		this.add(start);
		this.add(restart);
		
		//inclui o evento nos bot�es
		start.addActionListener(this);
		restart.addActionListener(this);
	}
	//m�todo de evento do bot�o ao ser pressionado
	public void actionPerformed(ActionEvent e)
	{	//se o bot�o for de inicio
		if(e.getSource().equals(start))
		{
			//se o campo de nome estiver vazio
			if(this.jt_nome.getText().isEmpty())
			{
				//exibe uma mensagem ao usu�rio
				JOptionPane.showMessageDialog(null, "Campo Participante vazio!");
				return;
			}
			
			//se for o bot�o de execu��o da forma
			//instancia a classe Execucao, que tem como par�metro o nome da forma
			ex = new Execucao(combo.getSelectedItem().toString(), this.jt_nome.getText());
			
			//torna o objeto "ex" vis�vel
			ex.setVisible(true);
			
			//apaga tudo que foi escrito em jt_nome
			this.jt_nome.setText("");
			
			//reinicia o combobox
			this.combo.setSelectedIndex(0);
			
			//bloqueia tudo desta janela
			this.jt_nome.setEnabled(false);
			this.combo.setEnabled(false);
			this.start.setEnabled(false);
		}
		else//sen�o
		{
			if(!ex.isVisible())
			{
				//desbloqueia tudo desta janela
				this.jt_nome.setEnabled(true);
				this.combo.setEnabled(true);
				this.start.setEnabled(true);
			}
		}
	}
}