package Tulls;

import java.io.*;
import java.io.IOException;
import java.util.Date;

import javax.swing.JOptionPane;

public class Relatorio 
{
	//variaveis de classe encapsuladas
	private String forma, nome;//strings que recebem nome do aluno e a forma executada
	private int resultado, mov;//resultado da avalia��o
	
	//construtor, recebe como parametro a forma, o participante e o devido resultado
	public Relatorio(String forma, String nome, int resultado, int mov)
	{
		this.nome = nome;
		this.forma = forma;
		this.resultado = resultado;
		this.mov = mov;
	}
	//m�todo para grava��o do relat�rio
	public void GravaRelatorio()
	{
		//cria um diret�rio para armazenamento de arquivo
		try 
		{	//instancia um FileWriter
			FileWriter fw = new FileWriter("C:/Users/Public/" + this.nome + "_" + this.forma + ".doc");
			
			//m�todo para gravar um relat�rio. Se j� existir o arquivo, ir� salvar e substituir o
			//existente.
			fw.write(this.getRelatorio());
			
			//libera��o de mem�ria
			fw.flush();
			//fecha o arquivo
			fw.close();
		}
		//se n�o for poss�vel salvar
		catch (IOException e) 
		{
			//envia mensagem de erro
			JOptionPane.showMessageDialog(null, "Erro de grava��o!\nFeche todos os outros programas", 
					"Aten��o", 1);
			return;
		}
	}
	//m�todo de acesso ao texto a ser gravado no relat�rio
	public String getRelatorio()
	{	//instancia uma Data
		Date data = new Date();
		return "UBT - Uni�o Brasileira de Taekwondo " + data.toLocaleString() +
				"\nNome: " + this.nome + "\nForma: " + this.forma + 
				" Tull\nResultado: Acertou " + this.resultado + " de " + this.mov + 
				"\nAproveitamento: " + String.valueOf(this.resultado*100/this.mov) + "%";
	}
	//m�todo que retorna o diret�rio do arquivo gravado
	public String getFile()
	{return "C:/Users/Public/" + this.nome + "_" + this.forma + ".doc";}
}
