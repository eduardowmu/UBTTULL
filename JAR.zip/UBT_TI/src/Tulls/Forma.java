package Tulls;
//classe de formas do taekwondo ITF.
public class Forma 
{//atributos das formas
	//nome da forma
	private String nome,//array dos nomes das formas
				   forma[] = {"Chon-Ji", "Dan-Gun", "Do-San", "Won-Hyo", "Yul-Gok", "Joong-Gun", "Toi-Gye", "Hwa-Rang", "Choong-Moo"};
	//quantidade de movimentos de cada forma
	private int movimentos,//array da quantidade de movimentos das formas
				quantidade[] = {19, 21, 24, 28, 38, 32, 37, 29, 30};
	//construtor, que recebe par�metros o nome da forma 
	//e sua respectiva quantidade de movimentos quantidade 
	public Forma(String forma)
	{	//inicializa os atributos
		nome = forma;
	}
	//GETTER que retorna o nome da forma
	public String getNome() 
	{return nome;}
	
	//SETTER que recebe o nome da forma
	public void setNome(String nome) 
	{this.nome = nome;}
	
	//GETTER que retorna a quantidade de movimentos
	public int getMovimentos() 
	{return movimentos;}
	
	//SETTER que recebe a quantidade de movimentos
	public void setMovimentos(String nome) 
	{
		//looping por todas as formas
		for(int i = 0; i < this.forma.length; i++)
		{	//se a forma for igual a uma dessas formas
			if(nome.equalsIgnoreCase(this.forma[i]))
			{	//iguala o numero de movimentos na respectiva quantidade
				this.movimentos = this.quantidade[i];
				break;//sai do looping
			}
		}
	}
}
