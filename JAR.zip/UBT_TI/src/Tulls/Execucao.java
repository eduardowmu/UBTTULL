package Tulls;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.swing.*;
public class Execucao extends JFrame
{
	//variavel tipo objeto encapsulado
	private ExecucaoPanel ep;
	
	//construtor
	public Execucao(String forma, String aluno)
	{	//permite fechar o frame
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		//Instancia classe Tollkit
		Toolkit toolkit = Toolkit.getDefaultToolkit();
				
		//cria uma dimens�o
		Dimension dtela = toolkit.getScreenSize();
				
		//dimensiona a tela com valores
		this.setSize(dtela.height/2, dtela.width/3);
				
		//posiciona a tela
		this.setLocation((int)dtela.height/4, (int)dtela.width/7);
				
		//cria uma imagem
		URL image = this.getClass().getResource("photo.png");
		ImageIcon icon = new ImageIcon(image);
				
		//insere a imagem no titulo do frame.
		this.setIconImage(icon.getImage());
		
		//intitula o Execucao
		this.setTitle(forma + " Tull");
		
		//instancia a classe ExecucaoPanel
		ep = new ExecucaoPanel(forma, aluno);
		
		ep.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 50));
		
		//add ep em Execucao
		this.add(ep);
	}
}
//classe ExecucaoPanel
class ExecucaoPanel extends JPanel implements ActionListener
{
	//vari�veis encapsuladas
	private int q;//tipo inteiro que recebe a quantidade de movimentos
	private String aluno, forma;//recebe nome do aluno e a forma que executou
	
	//objetos de classes encapsulados
	private JButton b1, b2;
	private JTextField jtf_qtd;
	private Forma tull;
	
	//construtor
	public ExecucaoPanel(String forma, String aluno)
	{	//define nome do aluno
		this.aluno = aluno;
		this.forma = forma;
		//instancia um JLabel
		JLabel jl_forma = new JLabel(forma + " Tull");
				
		//cria uma fonte para jl_qtd
		jl_forma.setFont(new Font("Arial", Font.PLAIN, 40));
				
		//add jl_qtd no ExecucaoPanel
		this.add(jl_forma);
		
		//instancia uma Forma
		tull = new Forma(forma);
		
		//define a quantidade de movimentos
		tull.setMovimentos(forma);
		
		//inicializa a variavel inteira q
		q = tull.getMovimentos();
		
		//instancia um JLabel
		JLabel jl_qtd = new JLabel("Movimentos: ");
		
		//cria uma fonte para jl_qtd
		jl_qtd.setFont(new Font("Arial", Font.PLAIN, 40));
		
		//add jl_qtd no ExecucaoPanel
		this.add(jl_qtd);
		
		//instancia um JTextField
		jtf_qtd = new JTextField(String.valueOf(this.getQtd()));
		
		//cria uma fonte ao jtf_qtd
		jtf_qtd.setFont(new Font("Arial", Font.PLAIN, 40));
		
		//bloqueia edi��o jtf_qtd
		jtf_qtd.setEditable(false);
		
		//add ao TullPanel
		this.add(jtf_qtd);
		
		//instancia os JButton`s
		b1 = new JButton("Descontar");
		b2 = new JButton(" Finalizar ");
		
		//add o m�todo dos devidos bot�es
		b1.addActionListener(this);
		b2.addActionListener(this);
		
		//add os bot�es no TullPanel
		this.add(b1);
		this.add(b2);
		
		//seleciona fonte nos bot�es
		b1.setFont(new Font("Arial", Font.PLAIN, 31));
		b2.setFont(new Font("Arial", Font.PLAIN, 32));
	}
	//m�todo de evento de um bot�o
	public void actionPerformed(ActionEvent e) 
	{
		//variavel tipo objeto que receber� o bot�o responsavel por algum evento
		Object button = e.getSource();
		
		//se for bot�o de descontar
		if(button == b1)
		{
			//m�todo que reduz a quatidade de movimentos corretos
			this.setQtd();
			
			//atualiza o texto no painel de movimentos
			jtf_qtd.setText(String.valueOf(this.getQtd()));
		}
		//se n�o
		else
		{
			//bloqueia o desconto de pontos
			b1.setEnabled(false);
			
			//gera um relat�rio
			Relatorio relatorio = new Relatorio(this.forma, this.aluno, this.getQtd(), 
					tull.getMovimentos());
			
			//Grava ou cria o relatorio
			relatorio.GravaRelatorio();
			
			//apresenta uma mensagem
			JOptionPane.showMessageDialog(null, this.aluno + " acertou " + this.getQtd() + " de " + 
					tull.getMovimentos() + "\nUm relat�rio foi salvo em: " + relatorio.getFile());
		
			//desabilita bot�o de finalizar
			b2.setEnabled(false);
		}
	}
	//m�todo que decrementa a quantidade de movimentos certos
	public void setQtd()
	{q--;}
	
	//m�todo acesso a quantidade de movimentos mostrado no painel
	public int getQtd()
	{return q;}
}