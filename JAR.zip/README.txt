It's for every taekwondo's ITF practicers, I developed an APP to evaluate a 
practicer in tulls exams. There is no license, it means, it's a free software.  